
mixed.table.m.8.rho.5 = read.csv(file  = "C:/Advancement/presentation/section-3-figures/mixed-table-m-8-rho-5.csv", header = T )
table.m.8.rho.5 = read.csv(file  = "C:/Advancement/presentation/section-3-figures/table-m-8-rho-5.csv")

plot(mixed.table.m.8.rho.5[1,])

dd = c(-3.3393,  -3.4375,	-3.8738,	-3.9349,	-3.8985)
plot(dd)
